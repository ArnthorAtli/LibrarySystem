package is.hi.hbv202g.assignment8;

public class EmptyAuthorListException extends Exception {
    public EmptyAuthorListException(String message) {
        super(message);
    }
}