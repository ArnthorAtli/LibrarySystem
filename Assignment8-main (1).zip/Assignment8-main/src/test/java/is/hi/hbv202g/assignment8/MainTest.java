package is.hi.hbv202g.assignment8;

import org.junit.Test;

/**
 * Unit test for simple Main.
 */
public class MainTest
{
    @Test
    public void shouldBePossibleToInstantiateLibrarySystem()
    {
        new LibrarySystem();
    }
}
